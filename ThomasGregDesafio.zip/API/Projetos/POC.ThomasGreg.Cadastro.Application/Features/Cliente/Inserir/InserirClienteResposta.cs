﻿using POC.ThomasGreg.Cadastro.Application.Compartilhado;

namespace POC.ThomasGreg.Cadastro.Application.Features.Cliente.Listar
{
    public class InserirClienteResposta : RespostaBase
    {
    }
}
