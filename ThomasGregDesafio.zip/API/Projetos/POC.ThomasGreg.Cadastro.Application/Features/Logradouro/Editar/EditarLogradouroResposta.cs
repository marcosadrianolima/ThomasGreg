﻿using POC.ThomasGreg.Cadastro.Application.Compartilhado;

namespace POC.ThomasGreg.Cadastro.Application.Features.Logradouro.Editar
{
    public class EditarLogradouroResposta : RespostaBase
    {
    }
}
