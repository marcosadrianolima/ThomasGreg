﻿using POC.ThomasGreg.Cadastro.Application.Compartilhado;

namespace POC.ThomasGreg.Cadastro.Application.Features.Logradouro.Excluir
{
    public class ExcluirLogradouroResposta : RespostaBase
    {
    }
}
