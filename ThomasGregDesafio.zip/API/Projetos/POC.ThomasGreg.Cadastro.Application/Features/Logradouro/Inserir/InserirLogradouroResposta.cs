﻿using POC.ThomasGreg.Cadastro.Application.Compartilhado;

namespace POC.ThomasGreg.Cadastro.Application.Features.Logradouro.Inserir
{
    public class InserirLogradouroResposta : RespostaBase
    {
    }
}
