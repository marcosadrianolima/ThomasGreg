﻿namespace POC.ThomasGreg.Cadastro.Domain
{
    public class Inicializacao
    {

    }
}
