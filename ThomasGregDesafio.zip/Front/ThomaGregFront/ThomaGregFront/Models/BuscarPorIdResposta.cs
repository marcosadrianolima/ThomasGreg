﻿namespace ThomaGregFront.Models
{
    public class BuscarPorIdResposta : RespostaBase
    {
        public ClienteDTO ClienteDTO { get; set; }
    }
}
