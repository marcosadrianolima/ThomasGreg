﻿namespace ThomaGregFront.Models
{
    public class EditarClienteResposta : RespostaBase
    {
    }
}
