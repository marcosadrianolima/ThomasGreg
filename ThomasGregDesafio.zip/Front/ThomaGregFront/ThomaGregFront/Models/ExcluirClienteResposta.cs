﻿namespace ThomaGregFront.Models
{
    public class ExcluirClienteResposta : RespostaBase
    {
    }
}
