﻿namespace ThomaGregFront.Models
{
    public class InserirClienteResposta : RespostaBase
    {
    }
}
