﻿namespace ThomaGregFront.Models
{
    public class ListarClienteResposta : RespostaBase
    {
        public List<ClienteDTO> ClienteDTOs { get; set; }
    }
}
