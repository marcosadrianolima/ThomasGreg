﻿namespace ThomaGregFront.Models
{
    public class LogradouroDTO
    {
        public long Id { get; set; }
        public string Nome { get; set; }
        public long ClienteId { get; set; }
    }
}
