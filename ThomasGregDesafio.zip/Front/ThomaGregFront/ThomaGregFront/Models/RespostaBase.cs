﻿namespace ThomaGregFront.Models
{
    public abstract class RespostaBase
    {
        public bool IsSucess { get; set; }
        public string Mensagem { get; set; }
    }
}
