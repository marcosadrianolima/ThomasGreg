﻿namespace ThomaGregFront.Models
{
    public class TokenResult
    {
        public string Token { get; set; }
    }
}
